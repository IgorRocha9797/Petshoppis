import React from 'react';
import { LucideIcon } from 'lucide-react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'neon-primary' | 'neon-secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  icon?: LucideIcon;
  fullWidth?: boolean;
  pulse?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'neon-primary', 
  size = 'md', 
  icon: Icon,
  fullWidth = false,
  pulse = false,
  className = '',
  ...props 
}) => {
  const baseStyles = "inline-flex items-center justify-center font-bold uppercase tracking-wider rounded-lg transition-all duration-300 transform hover:-translate-y-1 active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed";
  
  const variants = {
    // Changed primary to Red for Christmas theme
    'neon-primary': "bg-neon-red text-white hover:bg-white hover:text-neon-red hover:shadow-neon-red border border-transparent",
    // Secondary uses Green accents
    'neon-secondary': "bg-transparent border-2 border-neon-green text-neon-green hover:bg-neon-green hover:text-black hover:shadow-neon-green",
    'outline': "bg-transparent border border-gray-600 text-gray-300 hover:border-white hover:text-white",
    'ghost': "bg-white/10 backdrop-blur-sm text-white hover:bg-white/20"
  };

  const sizes = {
    sm: "text-xs px-4 py-2",
    md: "text-sm px-6 py-3",
    lg: "text-base px-8 py-4"
  };

  const widthClass = fullWidth ? "w-full" : "";
  const pulseClass = pulse ? "animate-pulse shadow-neon-red" : "";

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${sizes[size]} ${widthClass} ${pulseClass} ${className}`} 
      {...props}
    >
      {children}
      {Icon && <Icon className="ml-2 h-5 w-5" />}
    </button>
  );
};