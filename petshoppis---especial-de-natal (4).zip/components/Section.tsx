import React from 'react';

interface SectionProps {
  id?: string;
  children: React.ReactNode;
  className?: string;
  containerClassName?: string;
  bg?: 'dark' | 'darker' | 'gradient' | 'transparent';
}

export const Section: React.FC<SectionProps> = ({ 
  id, 
  children, 
  className = '', 
  containerClassName = '',
  bg = 'dark' 
}) => {
  const backgrounds = {
    dark: 'bg-dark-bg',
    darker: 'bg-dark-surface',
    gradient: 'bg-gradient-to-b from-dark-surface to-dark-bg',
    transparent: 'bg-transparent'
  };

  return (
    <section id={id} className={`py-12 md:py-16 ${backgrounds[bg]} ${className}`}>
      <div className={`container mx-auto px-4 max-w-7xl ${containerClassName}`}>
        {children}
      </div>
    </section>
  );
};